import Phaser from "phaser";
import { GAME_WIDTH, GAME_HEIGHT, COLORS } from "../config";
import { ObjectPool } from "../core/ObjectPool";
import { SaveManager } from "../core/SaveManager";

// === 게임 튜닝 상수 ===
const GAME_DURATION = 60; // 총 플레이 시간(초)
const FRUIT_RADIUS = 34; // 과일/폭탄 반지름
const GRAVITY = 900; // 아래로 당기는 가속도(px/s^2)
const BOMB_CHANCE = 0.15; // 폭탄 등장 확률
const FRUIT_SCORE = 10; // 과일 1개 점수
const BOMB_PENALTY = 20; // 폭탄 감점(0 밑으론 안 내려감)
const COMBO_BONUS = 5; // 한 번에 2개 이상 벨 때 추가 개당 보너스

// 도형 프로토타입용 과일 색 팔레트
const FRUIT_COLORS = [0xff5252, 0xffb142, 0xffd32a, 0x2ecc71, 0x54a0ff, 0xef5777];
const BOMB_COLOR = 0x1e1e1e;

// 화면에 떠다니는 개별 오브젝트. 물리는 vx/vy로 직접 적분한다.
interface Entity {
  arc: Phaser.GameObjects.Arc;
  vx: number;
  vy: number;
  kind: "fruit" | "bomb";
  sliced: boolean;
}

export class GameScene extends Phaser.Scene {
  private pool!: ObjectPool<Phaser.GameObjects.Arc>;
  private entities: Entity[] = [];

  private bladeGfx!: Phaser.GameObjects.Graphics;
  private trail: { x: number; y: number }[] = [];

  private score = 0;
  private scoreText!: Phaser.GameObjects.Text;
  private timeLeft = GAME_DURATION;
  private timeText!: Phaser.GameObjects.Text;

  private spawnTimer?: Phaser.Time.TimerEvent;
  private isOver = false;

  constructor() {
    super("GameScene");
  }

  create(): void {
    // scene.restart()로 재진입하므로 상태를 매번 초기화
    this.isOver = false;
    this.score = 0;
    this.timeLeft = GAME_DURATION;
    this.entities = [];
    this.trail = [];

    // 원(arc) 재사용 풀. acquire 시 색/위치만 갈아끼운다.
    this.pool = new ObjectPool<Phaser.GameObjects.Arc>(
      () => {
        const arc = this.add.circle(-100, -100, FRUIT_RADIUS, 0xffffff);
        arc.setActive(false).setVisible(false);
        return arc;
      },
      (arc) => {
        arc.setActive(false).setVisible(false);
        arc.setStrokeStyle(0); // 폭탄 테두리 제거
        arc.setPosition(-100, -100);
      }
    );

    // 칼날 궤적을 그릴 그래픽 레이어
    this.bladeGfx = this.add.graphics().setDepth(10);

    // HUD
    this.scoreText = this.add
      .text(16, 12, "SCORE 0", { fontFamily: "monospace", fontSize: "24px", color: COLORS.text, fontStyle: "bold" })
      .setDepth(20);
    this.timeText = this.add
      .text(GAME_WIDTH - 16, 12, `TIME ${this.timeLeft}`, { fontFamily: "monospace", fontSize: "24px", color: COLORS.text, fontStyle: "bold" })
      .setOrigin(1, 0)
      .setDepth(20);

    // 스폰 루프 시작 + 1초 카운트다운 + 60초 뒤 종료
    this.scheduleSpawn();
    this.time.addEvent({
      delay: 1000,
      loop: true,
      callback: () => {
        if (this.isOver) return;
        this.timeLeft -= 1;
        this.timeText.setText(`TIME ${Math.max(0, this.timeLeft)}`);
      },
    });
    this.time.delayedCall(GAME_DURATION * 1000, () => this.endGame());
  }

  update(_time: number, delta: number): void {
    const dt = delta / 1000;

    // 1) 칼날: 포인터가 눌린 동안만 궤적을 쌓고 슬라이스 판정
    const p = this.input.activePointer;
    if (!this.isOver && p.isDown) {
      this.trail.push({ x: p.worldX, y: p.worldY });
      if (this.trail.length > 12) this.trail.shift();
      if (this.trail.length >= 2) {
        this.checkSlice(this.trail[this.trail.length - 2], this.trail[this.trail.length - 1]);
      }
    } else {
      this.trail.length = 0; // 손 떼면 칼날 사라짐
    }
    this.drawBlade();

    // 2) 오브젝트 이동(중력 직접 적분) + 화면 아래로 지나간 것 회수
    for (let i = this.entities.length - 1; i >= 0; i--) {
      const e = this.entities[i];
      e.vy += GRAVITY * dt;
      e.arc.x += e.vx * dt;
      e.arc.y += e.vy * dt;
      if (e.arc.y > GAME_HEIGHT + FRUIT_RADIUS * 2 && e.vy > 0) {
        this.recycle(i);
      }
    }
  }

  /** 다음 스폰을 랜덤 간격으로 예약(재귀). */
  private scheduleSpawn(): void {
    if (this.isOver) return;
    this.spawnTimer = this.time.delayedCall(Phaser.Math.Between(550, 1000), () => {
      if (this.isOver) return;
      const count = Phaser.Math.Between(1, 2);
      for (let i = 0; i < count; i++) this.spawn();
      this.scheduleSpawn();
    });
  }

  /** 화면 아래에서 과일 또는 폭탄을 위로 쏘아 올린다. */
  private spawn(): void {
    const isBomb = Math.random() < BOMB_CHANCE;
    const arc = this.pool.acquire();

    const color = isBomb ? BOMB_COLOR : FRUIT_COLORS[Phaser.Math.Between(0, FRUIT_COLORS.length - 1)];
    arc.setFillStyle(color);
    arc.setStrokeStyle(isBomb ? 5 : 0, 0xff2d2d); // 폭탄은 빨간 테두리로 구분
    arc.setPosition(Phaser.Math.Between(80, GAME_WIDTH - 80), GAME_HEIGHT + FRUIT_RADIUS);
    arc.setActive(true).setVisible(true);

    this.entities.push({
      arc,
      vx: Phaser.Math.Between(-160, 160),
      vy: Phaser.Math.Between(-1000, -780), // 위로 발사(음수)
      kind: isBomb ? "bomb" : "fruit",
      sliced: false,
    });
  }

  /** a→b 칼날 세그먼트가 지나간 오브젝트를 벤다. */
  private checkSlice(a: { x: number; y: number }, b: { x: number; y: number }): void {
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    if (dx * dx + dy * dy < 16) return; // 거의 안 움직였으면 칼날 아님(드래그 강제)

    const line = new Phaser.Geom.Line(a.x, a.y, b.x, b.y);
    let fruitsThisSwing = 0;

    for (let i = this.entities.length - 1; i >= 0; i--) {
      const e = this.entities[i];
      if (e.sliced) continue;
      if (Phaser.Geom.Intersects.LineToCircle(line, new Phaser.Geom.Circle(e.arc.x, e.arc.y, FRUIT_RADIUS))) {
        e.sliced = true;
        if (e.kind === "bomb") {
          this.onBomb(e.arc.x, e.arc.y);
        } else {
          fruitsThisSwing++;
          this.onFruit(e.arc.x, e.arc.y, e.arc.fillColor);
        }
        this.recycle(i);
      }
    }

    if (fruitsThisSwing >= 2) {
      const bonus = (fruitsThisSwing - 1) * COMBO_BONUS;
      this.addScore(bonus);
      this.centerPopup(`COMBO x${fruitsThisSwing}  +${bonus}`, "#ffd32a");
    }
  }

  private onFruit(x: number, y: number, color: number): void {
    this.addScore(FRUIT_SCORE);
    this.burst(x, y, color);
    this.popup(x, y, `+${FRUIT_SCORE}`, "#ffffff");
  }

  private onBomb(x: number, y: number): void {
    this.addScore(-BOMB_PENALTY);
    this.cameras.main.flash(200, 255, 0, 0);
    this.cameras.main.shake(150, 0.012);
    this.popup(x, y, `-${BOMB_PENALTY}`, "#ff5252");
  }

  private addScore(delta: number): void {
    this.score = Math.max(0, this.score + delta);
    this.scoreText.setText(`SCORE ${this.score}`);
  }

  /** 벤 지점에서 과즙 파편이 튀는 연출. */
  private burst(x: number, y: number, color: number): void {
    for (let i = 0; i < 6; i++) {
      const bit = this.add.circle(x, y, Phaser.Math.Between(4, 9), color).setDepth(5);
      this.tweens.add({
        targets: bit,
        x: x + Phaser.Math.Between(-90, 90),
        y: y + Phaser.Math.Between(-90, 90),
        alpha: 0,
        duration: 450,
        onComplete: () => bit.destroy(),
      });
    }
  }

  private popup(x: number, y: number, text: string, color: string): void {
    const t = this.add.text(x, y, text, { fontFamily: "monospace", fontSize: "22px", color }).setOrigin(0.5).setDepth(15);
    this.tweens.add({ targets: t, y: y - 50, alpha: 0, duration: 600, onComplete: () => t.destroy() });
  }

  private centerPopup(text: string, color: string): void {
    const t = this.add
      .text(GAME_WIDTH / 2, GAME_HEIGHT / 2 - 40, text, { fontFamily: "monospace", fontSize: "30px", color, fontStyle: "bold" })
      .setOrigin(0.5)
      .setDepth(25);
    this.tweens.add({ targets: t, scale: 1.3, alpha: 0, duration: 700, onComplete: () => t.destroy() });
  }

  /** 칼날 궤적을 꼬리가 가늘어지도록 그린다. */
  private drawBlade(): void {
    this.bladeGfx.clear();
    for (let i = 1; i < this.trail.length; i++) {
      const alpha = i / this.trail.length;
      this.bladeGfx.lineStyle(2 + alpha * 8, 0xffffff, alpha);
      this.bladeGfx.beginPath();
      this.bladeGfx.moveTo(this.trail[i - 1].x, this.trail[i - 1].y);
      this.bladeGfx.lineTo(this.trail[i].x, this.trail[i].y);
      this.bladeGfx.strokePath();
    }
  }

  /** entities[i]를 풀에 반납하고 활성 목록에서 제거. */
  private recycle(i: number): void {
    this.pool.release(this.entities[i].arc);
    this.entities.splice(i, 1);
  }

  private endGame(): void {
    if (this.isOver) return;
    this.isOver = true;
    this.spawnTimer?.remove();
    this.trail.length = 0;
    this.bladeGfx.clear();

    const prevBest = SaveManager.get<number>("highscore", 0);
    const best = SaveManager.updateHighScore(this.score);
    const isNewBest = this.score > prevBest && this.score > 0;

    this.add.rectangle(GAME_WIDTH / 2, GAME_HEIGHT / 2, GAME_WIDTH, GAME_HEIGHT, 0x000000, 0.65).setDepth(30);
    this.add
      .text(GAME_WIDTH / 2, GAME_HEIGHT / 2 - 90, "TIME'S UP", { fontFamily: "monospace", fontSize: "44px", color: "#ffffff", fontStyle: "bold" })
      .setOrigin(0.5)
      .setDepth(31);
    this.add
      .text(GAME_WIDTH / 2, GAME_HEIGHT / 2 - 20, `SCORE ${this.score}`, { fontFamily: "monospace", fontSize: "30px", color: "#4cc9f0" })
      .setOrigin(0.5)
      .setDepth(31);
    this.add
      .text(GAME_WIDTH / 2, GAME_HEIGHT / 2 + 20, isNewBest ? "★ NEW BEST ★" : `BEST ${best}`, {
        fontFamily: "monospace",
        fontSize: "24px",
        color: isNewBest ? "#ffd32a" : "#ffffff",
      })
      .setOrigin(0.5)
      .setDepth(31);
    const prompt = this.add
      .text(GAME_WIDTH / 2, GAME_HEIGHT / 2 + 80, "탭 / 스페이스로 다시", { fontFamily: "monospace", fontSize: "18px", color: "#ffffff" })
      .setOrigin(0.5)
      .setDepth(31);
    this.tweens.add({ targets: prompt, alpha: 0.2, duration: 700, yoyo: true, repeat: -1 });

    // 종료 직후 오입력 방지용으로 잠깐 대기 후 재시작 입력 받기
    this.time.delayedCall(700, () => {
      this.input.once("pointerdown", () => this.scene.restart());
      this.input.keyboard?.once("keydown-SPACE", () => this.scene.restart());
    });
  }
}
